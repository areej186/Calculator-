﻿
namespace SimpleBasicCalculator
{
    partial class SimpleCalculator
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.Num7 = new System.Windows.Forms.Button();
            this.Num8 = new System.Windows.Forms.Button();
            this.Num9 = new System.Windows.Forms.Button();
            this.Num6 = new System.Windows.Forms.Button();
            this.Num5 = new System.Windows.Forms.Button();
            this.Num4 = new System.Windows.Forms.Button();
            this.Num3 = new System.Windows.Forms.Button();
            this.Num2 = new System.Windows.Forms.Button();
            this.Num1 = new System.Windows.Forms.Button();
            this.OpEquals = new System.Windows.Forms.Button();
            this.Num0 = new System.Windows.Forms.Button();
            this.NumDot = new System.Windows.Forms.Button();
            this.OpPlus = new System.Windows.Forms.Button();
            this.OpMinus = new System.Windows.Forms.Button();
            this.OpMultiply = new System.Windows.Forms.Button();
            this.OpDivide = new System.Windows.Forms.Button();
            this.OpClear = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.textBox1.Font = new System.Drawing.Font("Segoe UI", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.textBox1.Location = new System.Drawing.Point(12, 12);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(269, 66);
            this.textBox1.TabIndex = 0;
            // 
            // Num7
            // 
            this.Num7.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Num7.Location = new System.Drawing.Point(12, 97);
            this.Num7.Name = "Num7";
            this.Num7.Size = new System.Drawing.Size(62, 60);
            this.Num7.TabIndex = 1;
            this.Num7.Text = "7";
            this.Num7.UseVisualStyleBackColor = true;
            this.Num7.Click += new System.EventHandler(this.Num7_Click);
            // 
            // Num8
            // 
            this.Num8.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Num8.Location = new System.Drawing.Point(80, 97);
            this.Num8.Name = "Num8";
            this.Num8.Size = new System.Drawing.Size(63, 60);
            this.Num8.TabIndex = 2;
            this.Num8.Text = "8";
            this.Num8.UseVisualStyleBackColor = true;
            this.Num8.Click += new System.EventHandler(this.Num8_Click);
            // 
            // Num9
            // 
            this.Num9.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Num9.Location = new System.Drawing.Point(149, 97);
            this.Num9.Name = "Num9";
            this.Num9.Size = new System.Drawing.Size(63, 60);
            this.Num9.TabIndex = 3;
            this.Num9.Text = "9";
            this.Num9.UseVisualStyleBackColor = true;
            this.Num9.Click += new System.EventHandler(this.Num9_Click);
            // 
            // Num6
            // 
            this.Num6.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Num6.Location = new System.Drawing.Point(149, 163);
            this.Num6.Name = "Num6";
            this.Num6.Size = new System.Drawing.Size(63, 58);
            this.Num6.TabIndex = 4;
            this.Num6.Text = "6";
            this.Num6.UseVisualStyleBackColor = true;
            this.Num6.Click += new System.EventHandler(this.Num6_Click);
            // 
            // Num5
            // 
            this.Num5.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Num5.Location = new System.Drawing.Point(80, 163);
            this.Num5.Name = "Num5";
            this.Num5.Size = new System.Drawing.Size(63, 58);
            this.Num5.TabIndex = 5;
            this.Num5.Text = "5";
            this.Num5.UseVisualStyleBackColor = true;
            this.Num5.Click += new System.EventHandler(this.Num5_Click);
            // 
            // Num4
            // 
            this.Num4.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Num4.Location = new System.Drawing.Point(11, 163);
            this.Num4.Name = "Num4";
            this.Num4.Size = new System.Drawing.Size(63, 58);
            this.Num4.TabIndex = 6;
            this.Num4.Text = "4";
            this.Num4.UseVisualStyleBackColor = true;
            this.Num4.Click += new System.EventHandler(this.Num4_Click);
            // 
            // Num3
            // 
            this.Num3.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Num3.Location = new System.Drawing.Point(149, 227);
            this.Num3.Name = "Num3";
            this.Num3.Size = new System.Drawing.Size(63, 58);
            this.Num3.TabIndex = 7;
            this.Num3.Text = "3";
            this.Num3.UseVisualStyleBackColor = true;
            this.Num3.Click += new System.EventHandler(this.Num3_Click);
            // 
            // Num2
            // 
            this.Num2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Num2.Location = new System.Drawing.Point(80, 227);
            this.Num2.Name = "Num2";
            this.Num2.Size = new System.Drawing.Size(63, 58);
            this.Num2.TabIndex = 8;
            this.Num2.Text = "2";
            this.Num2.UseVisualStyleBackColor = true;
            this.Num2.Click += new System.EventHandler(this.Num2_Click);
            // 
            // Num1
            // 
            this.Num1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Num1.Location = new System.Drawing.Point(12, 227);
            this.Num1.Name = "Num1";
            this.Num1.Size = new System.Drawing.Size(63, 58);
            this.Num1.TabIndex = 9;
            this.Num1.Text = "1";
            this.Num1.UseVisualStyleBackColor = true;
            this.Num1.Click += new System.EventHandler(this.Num1_Click);
            // 
            // OpEquals
            // 
            this.OpEquals.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.OpEquals.Location = new System.Drawing.Point(149, 291);
            this.OpEquals.Name = "OpEquals";
            this.OpEquals.Size = new System.Drawing.Size(63, 58);
            this.OpEquals.TabIndex = 10;
            this.OpEquals.Text = "=";
            this.OpEquals.UseVisualStyleBackColor = true;
            this.OpEquals.Click += new System.EventHandler(this.OpEquals_Click);
            // 
            // Num0
            // 
            this.Num0.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Num0.Location = new System.Drawing.Point(80, 291);
            this.Num0.Name = "Num0";
            this.Num0.Size = new System.Drawing.Size(63, 58);
            this.Num0.TabIndex = 11;
            this.Num0.Text = "0";
            this.Num0.UseVisualStyleBackColor = true;
            this.Num0.Click += new System.EventHandler(this.Num0_Click);
            // 
            // NumDot
            // 
            this.NumDot.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.NumDot.Location = new System.Drawing.Point(12, 291);
            this.NumDot.Name = "NumDot";
            this.NumDot.Size = new System.Drawing.Size(63, 58);
            this.NumDot.TabIndex = 12;
            this.NumDot.Text = ".";
            this.NumDot.UseVisualStyleBackColor = true;
            this.NumDot.Click += new System.EventHandler(this.NumDot_Click);
            // 
            // OpPlus
            // 
            this.OpPlus.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.OpPlus.Location = new System.Drawing.Point(218, 291);
            this.OpPlus.Name = "OpPlus";
            this.OpPlus.Size = new System.Drawing.Size(63, 58);
            this.OpPlus.TabIndex = 13;
            this.OpPlus.Text = "+";
            this.OpPlus.UseVisualStyleBackColor = true;
            this.OpPlus.Click += new System.EventHandler(this.OpPlus_Click);
            // 
            // OpMinus
            // 
            this.OpMinus.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.OpMinus.Location = new System.Drawing.Point(218, 227);
            this.OpMinus.Name = "OpMinus";
            this.OpMinus.Size = new System.Drawing.Size(63, 58);
            this.OpMinus.TabIndex = 14;
            this.OpMinus.Text = "-";
            this.OpMinus.UseVisualStyleBackColor = true;
            this.OpMinus.Click += new System.EventHandler(this.OpMinus_Click);
            // 
            // OpMultiply
            // 
            this.OpMultiply.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.OpMultiply.Location = new System.Drawing.Point(218, 163);
            this.OpMultiply.Name = "OpMultiply";
            this.OpMultiply.Size = new System.Drawing.Size(63, 58);
            this.OpMultiply.TabIndex = 15;
            this.OpMultiply.Text = "*";
            this.OpMultiply.UseVisualStyleBackColor = true;
            this.OpMultiply.Click += new System.EventHandler(this.button15_Click);
            // 
            // OpDivide
            // 
            this.OpDivide.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.OpDivide.Location = new System.Drawing.Point(218, 97);
            this.OpDivide.Name = "OpDivide";
            this.OpDivide.Size = new System.Drawing.Size(63, 58);
            this.OpDivide.TabIndex = 16;
            this.OpDivide.Text = "/";
            this.OpDivide.UseVisualStyleBackColor = true;
            this.OpDivide.Click += new System.EventHandler(this.OpDivide_Click);
            // 
            // OpClear
            // 
            this.OpClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.OpClear.Location = new System.Drawing.Point(12, 355);
            this.OpClear.Name = "OpClear";
            this.OpClear.Size = new System.Drawing.Size(269, 59);
            this.OpClear.TabIndex = 17;
            this.OpClear.Text = "Clear";
            this.OpClear.UseVisualStyleBackColor = true;
            this.OpClear.Click += new System.EventHandler(this.button17_Click);
            // 
            // SimpleCalculator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.ClientSize = new System.Drawing.Size(295, 431);
            this.Controls.Add(this.OpClear);
            this.Controls.Add(this.OpDivide);
            this.Controls.Add(this.OpMultiply);
            this.Controls.Add(this.OpMinus);
            this.Controls.Add(this.OpPlus);
            this.Controls.Add(this.NumDot);
            this.Controls.Add(this.Num0);
            this.Controls.Add(this.OpEquals);
            this.Controls.Add(this.Num1);
            this.Controls.Add(this.Num2);
            this.Controls.Add(this.Num3);
            this.Controls.Add(this.Num4);
            this.Controls.Add(this.Num5);
            this.Controls.Add(this.Num6);
            this.Controls.Add(this.Num9);
            this.Controls.Add(this.Num8);
            this.Controls.Add(this.Num7);
            this.Controls.Add(this.textBox1);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.MaximizeBox = false;
            this.Name = "SimpleCalculator";
            this.Text = "SimpleCalculator";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button Num7;
        private System.Windows.Forms.Button Num8;
        private System.Windows.Forms.Button Num9;
        private System.Windows.Forms.Button Num6;
        private System.Windows.Forms.Button Num5;
        private System.Windows.Forms.Button Num4;
        private System.Windows.Forms.Button Num3;
        private System.Windows.Forms.Button Num2;
        private System.Windows.Forms.Button Num1;
        private System.Windows.Forms.Button OpEquals;
        private System.Windows.Forms.Button Num0;
        private System.Windows.Forms.Button NumDot;
        private System.Windows.Forms.Button OpPlus;
        private System.Windows.Forms.Button OpMinus;
        private System.Windows.Forms.Button OpMultiply;
        private System.Windows.Forms.Button OpDivide;
        private System.Windows.Forms.Button OpClear;
    }
}

